#!/bin/sh
DAENON_PATH='daemon'
PAGES_PATH='pages'
HLOR_DIRECTORY=$HOME/.hlor
HLOR_TEST_DATA="$HOME/.hlor/test.dat"

HLOR_DAEMON_PATH='/etc/init.d/hlor-daemon.sh'
HLOR_SCRIPT_PATH='/usr/sbin/hlor-daemon-script.sh'
HLOR_APP_PATH='/usr/sbin/hlor-app'
HLOR_CONFIG_PATH='/config/hlor.conf'
HLOR_SSL_CERT=/etc/ssl/certs/ca-certificates.crt

if [ -f "$HLOR_DAEMON_PATH" ]
then
	rm $HLOR_DAEMON_PATH
fi

cp "$DAENON_PATH/hlor-daemon.sh" '/etc/init.d/'
chmod ug+x '/etc/init.d/hlor-daemon.sh'

if [ -f "$HLOR_SCRIPT_PATH" ]
then
	rm $HLOR_SCRIPT_PATH
fi

cp "$DAENON_PATH/script.sh" '/usr/sbin/hlor-daemon-script.sh'
chmod ug+x '/usr/sbin/hlor-daemon-script.sh'

if [ -f "$HLOR_CONFIG_PATH" ]
then
	rm $HLOR_CONFIG_PATH
fi

cp "$DAENON_PATH/hlor.conf" "/config/hlor.conf"

if [ ! -d "$HLOR_DIRECTORY" ]
then
	mkdir $HLOR_DIRECTORY
fi	

if [ -f "$HLOR_TEST_DATA" ]
then
	rm $HLOR_TEST_DATA
fi

cp "$DAENON_PATH/test.dat" "$HOME/.hlor/test.dat"

if [ -f "$HLOR_APP_PATH" ]
then
	rm $HLOR_APP_PATH
fi

#update pages
cp -r "$PAGES_PATH" '/www'

#install button
/bin/sh ./add_button.sh
#end install button

cp "$DAENON_PATH/cpp/hlor-app" '/usr/sbin/hlor-app'
chmod ug+x '/usr/sbin/hlor-app'

if [ ! -d '/etc/ssl/certs/' ]
then
	mkdir -p /etc/ssl/certs/
fi

#check certificate file
if [ ! -f "$HLOR_SSL_CERT" ]
then

	cp $DAENON_PATH/cacert.pem $HLOR_SSL_CERT
	
fi

#cehck curl version
CURL_VERSION=$(curl --version | awk 'NR==1 {print $2}')

if [ $CURL_VERSION != '7.37.1' ]
then
	opkg install $DAENON_PATH/depends/libc6_2.20-r0.8_armv7at2hf-vfp.ipk &> /dev/null
	opkg install $DAENON_PATH/depends/libz1_1.2.8-r0.9_armv7at2hf-vfp.ipk &> /dev/null
	opkg install $DAENON_PATH/depends/libgmp10_6.0.0-r0.9_armv7at2hf-vfp.ipk &> /dev/null
	opkg install $DAENON_PATH/depends/nettle_2.7.1-r0.9_armv7at2hf-vfp.ipk &> /dev/null
	opkg install $DAENON_PATH/depends/libgnutls28_3.3.5-r0.9_armv7at2hf-vfp.ipk &> /dev/null
	opkg install $DAENON_PATH/depends/libcurl5_7.37.1-r0.5_armv7at2hf-vfp.ipk &> /dev/null
	opkg install $DAENON_PATH/depends/curl_7.37.1-r0.5_armv7at2hf-vfp.ipk &> /dev/null
	opkg install $DAENON_PATH/depends/libstdc++6_linaro-4.9-r2014.11.8_armv7at2hf-vfp.ipk &> /dev/null
fi

update-rc.d 'hlor-daemon.sh' defaults &> /dev/null

killall -9 hlor-daemon-script.sh &> /dev/null
killall -9 hlor-app &> /dev/null

sh /etc/init.d/hlor-daemon.sh start &> /dev/null

rm -rf *.tar.gz

#/sbin/reboot -f &> /dev/null

#mkdir -p /etc/ssl/certs/
#cd /etc/ssl/certs/
#curl --remote-name --time-cond cacert.pem https://curl.haxx.se/ca/cacert.pem
