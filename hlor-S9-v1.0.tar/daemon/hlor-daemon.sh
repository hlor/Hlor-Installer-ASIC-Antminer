#!/bin/sh

### BEGIN INIT INFO
# Provides:          hlor-daemon
# Required-Start:
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:      1 0 6
# Short-Description: HLOR Daemon
# Description: HLOR Daemon
### END INIT INFO

PATH=/sbin:/bin:/usr/sbin:/usr/bin
DAEMON=/usr/sbin/hlor-daemon-script.sh
NAME=hlor-daemon
DESC="HLOR Daemon"
OPTS="-D"


case "$1" in
  start)
        echo -n "Starting $DESC: "
        start-stop-daemon --start --background -x $DAEMON
        echo "$NAME."
        ;;
  stop)
        echo -n "Stopping $DESC: "
        start-stop-daemon -Kvx /bin/sh $DAEMON
        echo "$NAME."
        ;;
  *)
        N=/etc/init.d/$NAME
        echo "Usage: $N {start|stop}" >&2
        exit 1
        ;;
esac

exit 0
