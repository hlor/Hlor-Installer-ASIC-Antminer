#!/bin/sh

#if you need run program as script change next variable as true
RUN_AS_SCRIPT=false
DEBUG=true

PATH_TO_CERTIFICATE=/etc/ssl/certs/ca-certificates.crt

DT=$(date '+%d/%m/%Y %H:%M:%S'); #current date for logs

echo "-------------------------------------------------------------------------" > /var/log/hlor-daemon.log
echo "" >> /var/log/hlor-daemon.log
echo "Hlor ASIC Antminer S9 Addon for miners with enabled LPM" >> /var/log/hlor-daemon.log
echo "To download the latest version, please visit our Github account" >> /var/log/hlor-daemon.log
echo "" >> /var/log/hlor-daemon.log
echo " * Source Code:    https://github.com/hlor/Hlor-ASIC-Antminer-S9/releases" >> /var/log/hlor-daemon.log
echo " * Explorer:       https://hlor.io/" >> /var/log/hlor-daemon.log
echo " * Support:        https://hlor.io/contact/" >> /var/log/hlor-daemon.log
echo "" >> /var/log/hlor-daemon.log
echo "-------------------------------------------------------------------------" >> /var/log/hlor-daemon.log
echo "" >> /var/log/hlor-daemon.log
echo "Make sure you have established internet connection " >> /var/log/hlor-daemon.log
echo "" >> /var/log/hlor-daemon.log
echo "-------------------------------------------------------------------------" >> /var/log/hlor-daemon.log
echo "[$DT] Start hlor daemon..." >> /var/log/hlor-daemon.log

sleep 120

while true
do

	DT=$(date '+%d/%m/%Y %H:%M:%S'); #current date for logs


	if $RUN_AS_SCRIPT; then
		. "$PWD/hlor.conf" #read configuration file
	else
		. "/config/hlor.conf" #read configuration file
	fi


	if $DEBUG; then
		echo "Username: $hlor_user" 
		echo "Key: $hlor_key"
		echo "Worker Name: $hlor_wname"
		echo "Version: $hlor_version"
	fi

	BMMINER_CONFIG=/config/bmminer.conf

	unit=$(sed -n 2p /usr/bin/compile_time)
	hlor-app --user $hlor_user --key $hlor_key --wname $hlor_wname --unit "\"$unit\"" --cacert $PATH_TO_CERTIFICATE --bmminer-config $BMMINER_CONFIG

	
	LOGSIZE=$(stat -c%s /var/log/hlor-daemon.log)
	CLEAR_LOG_SIZE=200480
	#if log have 20480 (20kb) then clear log.
	if [ "$LOGSIZE" -gt "$CLEAR_LOG_SIZE" ]; then
		cat /dev/null > /var/log/hlor-daemon.log
		echo "Clear logs ... $LOGSIZE" > /var/log/hlor-daemon.log
	fi	
done
