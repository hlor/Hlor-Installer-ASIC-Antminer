(function($){
	$(document).ready(function(){
		
		var checkStatus = function(){
			$.ajax({
				url: '/cgi-bin/hlor_connection_status.cgi',
				type: 'GET',
				dataType: 'text',
				timeout: 30000,
				cache: false,
				success: function(data) {
					console.log(data);
					$('#hlor_connection_status').attr('src', data);
				},
				error: function() {
					//alert('Ajax Error');
				}
			});
		};	

		var auth = function() {
			$.ajax({
				url: '/cgi-bin/get_hlor_auth.cgi',
				type: 'GET',
				dataType: 'text',
				timeout: 30000,
				cache: false,
				success: function(data) {
		

					try
					{
						console.log(data);
						
						data = data.trim();	

						if (data == 'Fail') {
							$('#hlor_connection_status').attr('src', '/resources/icons/tunnel_disabled.png');

							if ($('#access-denied').length > 0) {
								$('#access-denied').fadeIn(500);
							}

						} else if (data == 'Accept Deprecated') {
							$('#hlor_connection_status').attr('src', '/resources/icons/tunnel_disabled.png');

							if ($('#version-deprecated').length > 0) {
								$('#version-deprecated').fadeIn(500);
							}

						} else if (data == "Accept") {
							$('#access-denied').fadeOut(500);
							$('#version-deprecated').fadeOut(500);
							checkStatus();
						}
						coin();	
					}
					catch(err)
					{
						alert('Invalid Miner configuration file. Edit manually or reset to default.');
					}
				},
				error: function() {
					//alert('Ajax Error');
				}
			});
		}

		var coin = function() {
			$.ajax({
				url: '/cgi-bin/get_hlor_coin.cgi',
				type: 'GET',
				dataType: 'text',
				timeout: 30000,
				cache: false,
				success: function(data) {
		

					try
					{
						console.log(data);
						
						data = data.trim();	

						if (data == 'Undefined') {
							$('#hlor_connection_status').attr('src', '/resources/icons/tunnel_disabled.png');
						} else {
							$('#hlor_connection_status').attr('src', '/resources/icons/tunnel.png');
						}

					}
					catch(err)
					{
						alert('Invalid Miner configuration file. Edit manually or reset to default.');
					}
				},
				error: function() {
					//alert('Ajax Error');
				}
			});
		}

		//check auth after init page
		auth();

		//check status each 30 seconds
		setInterval(function(){
			auth();

		}, 30000);


	});
})(jQuery);